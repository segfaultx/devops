#!/usr/bin/env python3

import datetime

print("Content-Type: text/html\n\n") 
print( '<html><head><meta content="text/html; charset=UTF-8" />')
print( '<title>Rapsberry Pi</title><p>')
print( datetime.datetime.now())
print( "</p></body></html>") 
